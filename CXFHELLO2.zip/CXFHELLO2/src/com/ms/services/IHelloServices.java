package com.ms.services;  
  
import java.util.List;  
import javax.jws.WebService;  
  
@WebService  
public interface IHelloServices {  
    public String sayHello(String name);  
}