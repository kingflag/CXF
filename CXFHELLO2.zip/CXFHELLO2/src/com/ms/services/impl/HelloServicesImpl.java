package com.ms.services.impl;  
  
import java.util.List;  
import javax.jws.WebService;  
import com.ms.services.IHelloServices;  
  
@WebService(serviceName="com.ms.services.IHelloServices")
public class HelloServicesImpl implements IHelloServices { 
	
  
    public String sayHello(String name) {  
        return "Hello "+name+" .";  
    }  
} 