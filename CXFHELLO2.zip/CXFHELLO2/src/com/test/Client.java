package com.test;  
  
import java.util.ArrayList;  
import java.util.List;  
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;  
import org.springframework.context.ApplicationContext;  
import org.springframework.context.support.ClassPathXmlApplicationContext;  
import com.ms.services.IHelloServices;  
  
public class Client {  
    public static void main(String[] args) {  
    	invoke();  
    }  
     
    /** 
     * ͨ��Spring����webservices 
     */  
    public static void invokeBySpring(){  
    	//����WebService�ͻ��˴�������      
        JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();     
        //ע��WebService�ӿ�      
        factory.setServiceClass(IHelloServices.class);     
       //����WebService��ַ      
        factory.setAddress("http://localhost:9090/helloServices");          
        IHelloServices iHelloWorld = (IHelloServices)factory.create();     
        System.out.println(iHelloWorld.sayHello("ximing"));
        System.exit(0);     
    }  
     
    public static void invoke(){  
        //����WebService�ͻ��˴�������      
        JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();     
        //ע��WebService�ӿ�      
        factory.setServiceClass(IHelloServices.class);     
        //����WebService��ַ      
        factory.setAddress("http://localhost:9090/CXFHELLO2/services/HelloServices?wsdl");          
        IHelloServices helloServices = (IHelloServices)factory.create();     
        System.out.println("invoke helloServices webservice...");  
        String hello = helloServices.sayHello("caiyasi");  
          
       System.out.println(hello);  
    }  
}  