package com.ws.services;  
import javax.jws.WebService;  
  
@WebService  
public interface IHelloServices {  
//    public String sayHelloToAll(String[] userNames);  
  
//    public String[] getHelloWords();  
      
    public String sayHello(String name);  
}  
