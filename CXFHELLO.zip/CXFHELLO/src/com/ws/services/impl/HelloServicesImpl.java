package com.ws.services.impl;  
  
import javax.jws.WebService;  
  
import com.ws.services.IHelloServices;  
  
@WebService(endpointInterface="com.ws.services.IHelloServices")  
public class HelloServicesImpl implements IHelloServices {  
  
//    public String[] getHelloWords() {  
//        String[] words = {"hello vicky.","hello,i'm vicky.","hi,ivy and simon."};  
//        return words;  
//    }  
  
    public String sayHello(String name) {  
        return "hello "+name+" ! ";  
    }  
  
//    public String sayHelloToAll(String[] userNames) {  
//       String hello = "hello ";  
//        for(int i=0;i<userNames.length;i++){  
//            if(i!=userNames.length-1)  
//                hello += userNames[i]+" and ";  
//            else  
//                hello += userNames[i]+" .";  
//        }  
//        return hello;  
//    }  
  
}