package com.ws.services;  
  
import javax.xml.ws.Endpoint;  
import org.apache.cxf.jaxws.JaxWsServerFactoryBean;  
import com.ws.services.IHelloServices;  
import com.ws.services.impl.HelloServicesImpl;  
  
public class ServerTest {  
    public ServerTest(){  
//        // ��һ�ַ�����ʽ   
//        IHelloServices hello = new HelloServicesImpl();  
//        // ����WebServices����ӿ�   
//        JaxWsServerFactoryBean factory = new JaxWsServerFactoryBean();  
//        // ע��webservices�ӿ�   
//        factory.setServiceClass(IHelloServices.class);  
//        // �����ӿ�   
//        factory.setAddress("http://localhost:8090/helloServices");  
//        factory.setServiceBean(hello);  
//        // ��������   
//        factory.create();  
          
//         �ڶ��ַ�����ʽ   
       Endpoint.publish("http://localhost:8090/helloServices", new HelloServicesImpl());   
    }  
    public static void main(String[] args) {  
        // ��������   
        new ServerTest();  
        System.out.println("Server ready...");     
        try {  
            Thread.sleep(1000*300); //������ַ��ӣ����ڲ���      
        } catch (InterruptedException e) {  
            e.printStackTrace();  
       }     
        System.out.println("Server exit...");     
        System.exit(0);  
    }  
}  
