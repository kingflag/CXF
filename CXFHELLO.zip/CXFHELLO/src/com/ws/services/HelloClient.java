package com.ws.services;  
  
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;  
import com.ws.services.IHelloServices;  
  
public class HelloClient {  
    public static void main(String[] args) {  
        //����WebService�ͻ��˴�������      
        JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();     
        //ע��WebService�ӿ�      
        factory.setServiceClass(IHelloServices.class);     
       //����WebService��ַ      
        factory.setAddress("http://localhost:8090/helloServices");          
        IHelloServices iHelloWorld = (IHelloServices)factory.create();     
        System.out.println(iHelloWorld.sayHello("ximing"));
        System.exit(0);     
    }    
}  
